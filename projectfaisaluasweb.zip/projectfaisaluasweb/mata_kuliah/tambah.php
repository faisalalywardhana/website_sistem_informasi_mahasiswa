<?php
session_start(); // Memulai session agar bisa mengecek status login pengguna
include '../includes/db.php';     // Menghubungkan ke database
include '../includes/auth.php';   // Mengecek apakah user sudah login dan punya izin
include '../includes/header.php'; // Menampilkan bagian header dari halaman

// Inisialisasi variabel
$error = '';
$kode_mk = '';
$nama_mk = '';
$sks = '';
$semester = '';

// ---------------------------
// Proses saat form disubmit
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari input form
    $kode_mk = $_POST['kode_mk'] ?? '';
    $nama_mk = $_POST['nama_mk'] ?? '';
    $sks = $_POST['sks'] ?? '';
    $semester = $_POST['semester'] ?? '';

    // Validasi: Pastikan semua input tidak kosong
    if ($kode_mk && $nama_mk && $sks && $semester) {
        // Simpan data ke database dengan prepared statement
        $stmt = $conn->prepare("INSERT INTO mata_kuliah (kode_mk, nama_mk, sks, semester) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssis", $kode_mk, $nama_mk, $sks, $semester); // ssis: string, string, integer, string
        $stmt->execute();

        // Setelah berhasil disimpan, redirect ke index
        header("Location: index.php");
        exit;
    } else {
        // Tampilkan error jika ada input yang kosong
        $error = "Semua kolom harus diisi.";
    }
}
?>

<!-- Tampilan Form Tambah Mata Kuliah -->
<div class="container mt-4">
    <h4>Tambah Mata Kuliah</h4>

    <!-- Menampilkan pesan error jika ada -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form untuk input data mata kuliah -->
    <form method="POST">
        <div class="mb-3">
            <label for="kode_mk" class="form-label">Kode MK</label>
            <input type="text" name="kode_mk" id="kode_mk" class="form-control" required value="<?= htmlspecialchars($kode_mk) ?>">
        </div>
        <div class="mb-3">
            <label for="nama_mk" class="form-label">Nama Mata Kuliah</label>
            <input type="text" name="nama_mk" id="nama_mk" class="form-control" required value="<?= htmlspecialchars($nama_mk) ?>">
        </div>
        <div class="mb-3">
            <label for="sks" class="form-label">SKS</label>
            <input type="number" name="sks" id="sks" class="form-control" required value="<?= htmlspecialchars($sks) ?>">
        </div>
        <div class="mb-3">
            <label for="semester" class="form-label">Semester</label>
            <input type="number" name="semester" id="semester" class="form-control" required value="<?= htmlspecialchars($semester) ?>">
        </div>

        <!-- Tombol Simpan dan Kembali -->
        <button class="btn btn-primary">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; // Menyisipkan bagian footer ?>
