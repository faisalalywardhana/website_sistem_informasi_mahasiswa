<?php
session_start(); // Nyalain session biar bisa ngecek user udah login apa belum

include '../includes/db.php';      // Konek ke database
include '../includes/auth.php';    // Cek dulu, user udah login apa belum
include '../includes/header.php';  // Tampilan bagian atas (navbar, CSS, dsb.)

// ----------------------
// Fitur cari-cari data
// ----------------------
$keyword = $_GET['search'] ?? ''; // Ambil keyword dari URL, kalau ada
$sql = "SELECT * FROM mata_kuliah WHERE nama_mk LIKE ? ORDER BY id DESC"; // Query buat nyari berdasarkan nama MK
$stmt = $conn->prepare($sql); // Siapin query-nya
$likeKeyword = '%' . $keyword . '%'; // Biar pencariannya fleksibel (bisa sebagian kata)
$stmt->bind_param("s", $likeKeyword); // Masukin keyword-nya ke query (biar aman dari SQL injection)
$stmt->execute(); // Eksekusi query
$result = $stmt->get_result(); // Ambil hasilnya
?>

<div class="container mt-4">
    <!-- Judul halaman + tombol buat nambah data baru -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Data Mata Kuliah</h4>
        <a href="tambah.php" class="btn btn-success">+ Tambah Mata Kuliah</a>
    </div>

    <!-- Form pencarian -->
    <form method="GET" class="mb-3">
        <input type="text" name="search" class="form-control" placeholder="Cari nama mata kuliah..." value="<?= htmlspecialchars($keyword) ?>">
        <!-- Biar field-nya tetap terisi sama keyword sebelumnya -->
    </form>

    <!-- Tabel buat nampilin data mata kuliah -->
    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Kode MK</th>
                <th>Nama Mata Kuliah</th>
                <th>SKS</th>
                <th>Semester</th>
                <th>Aksi</th> <!-- Tombol edit & hapus -->
            </tr>
        </thead>
        <tbody>
            <!-- Loop buat nampilin tiap data dari database -->
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['kode_mk']) ?></td>
                    <td><?= htmlspecialchars($row['nama_mk']) ?></td>
                    <td><?= $row['sks'] ?></td>
                    <td><?= $row['semester'] ?></td>
                    <td>
                        <!-- Tombol edit, klik buat ngedit data -->
                        <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                        <!-- Tombol hapus, ada konfirmasi dulu biar nggak kehapus tanpa sengaja -->
                        <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; // Tampilkan bagian footer (penutup halaman) ?>
