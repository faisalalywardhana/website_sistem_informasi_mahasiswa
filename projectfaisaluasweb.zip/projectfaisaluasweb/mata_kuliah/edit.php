<?php
session_start(); // Nyalain session biar bisa akses data login user

include '../includes/db.php';     // Konek ke database
include '../includes/auth.php';   // Cek dulu, user udah login atau belum
include '../includes/header.php'; // Tampilan atas (navbar, CSS, dll)

// Ambil ID dari URL, biasanya dari tombol edit
$id = $_GET['id'] ?? null;
$error = '';
$kode_mk = '';
$nama_mk = '';
$sks = '';
$semester = '';

// ===============================
// Ambil data lama dari database
// ===============================
if ($id) {
    // Cek data mata kuliah berdasarkan id
    $stmt = $conn->prepare("SELECT * FROM mata_kuliah WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $mk = $result->fetch_assoc();

    // Kalau data gak ada, tampilin pesan
    if (!$mk) {
        echo "<div class='container mt-4 alert alert-danger'>Mata kuliah tidak ditemukan. <a href='index.php'>Kembali</a></div>";
        include '../includes/footer.php';
        exit;
    }

    // Simpan data ke variabel biar bisa ditampilin di form
    $kode_mk = $mk['kode_mk'];
    $nama_mk = $mk['nama_mk'];
    $sks = $mk['sks'];
    $semester = $mk['semester'];
} else {
    // Kalau gak ada ID di URL, kasih pesan error
    echo "<div class='container mt-4 alert alert-danger'>ID tidak ditemukan. <a href='index.php'>Kembali</a></div>";
    include '../includes/footer.php';
    exit;
}

// ===============================
// Proses saat tombol Update diklik
// ===============================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $kode_mk = $_POST['kode_mk'] ?? '';
    $nama_mk = $_POST['nama_mk'] ?? '';
    $sks = $_POST['sks'] ?? '';
    $semester = $_POST['semester'] ?? '';

    // Cek kalau semua field harus diisi
    if ($kode_mk && $nama_mk && $sks && $semester) {
        // Update ke database pake prepared statement
        $stmt = $conn->prepare("UPDATE mata_kuliah SET kode_mk = ?, nama_mk = ?, sks = ?, semester = ? WHERE id = ?");
        $stmt->bind_param("ssisi", $kode_mk, $nama_mk, $sks, $semester, $id);
        $stmt->execute();

        // Setelah berhasil update, balik ke halaman index
        header("Location: index.php");
        exit;
    } else {
        // Kalau ada yang kosong, kasih error
        $error = "Semua kolom harus diisi.";
    }
}
?>

<div class="container mt-4">
    <h4>Edit Mata Kuliah</h4>

    <!-- Tampilin error kalau ada -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form edit MK -->
    <form method="POST">
        <div class="mb-3">
            <label for="kode_mk" class="form-label">Kode MK</label>
            <input type="text" name="kode_mk" id="kode_mk" class="form-control" required value="<?= htmlspecialchars($kode_mk) ?>">
        </div>
        <div class="mb-3">
            <label for="nama_mk" class="form-label">Nama Mata Kuliah</label>
            <input type="text" name="nama_mk" id="nama_mk" class="form-control" required value="<?= htmlspecialchars($nama_mk) ?>">
        </div>
        <div class="mb-3">
            <label for="sks" class="form-label">SKS</label>
            <input type="number" name="sks" id="sks" class="form-control" required value="<?= htmlspecialchars($sks) ?>">
        </div>
        <div class="mb-3">
            <label for="semester" class="form-label">Semester</label>
            <input type="number" name="semester" id="semester" class="form-control" required value="<?= htmlspecialchars($semester) ?>">
        </div>
        <!-- Tombol buat simpan dan balik -->
        <button class="btn btn-primary">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; // Bagian bawah halaman ?>
