<?php
session_start(); // Memulai session, penting untuk mengecek login user

include '../includes/db.php';   // Menghubungkan ke database
include '../includes/auth.php'; // Mengecek apakah user sudah login (proteksi akses)

// Ambil nilai id dari parameter GET (misalnya: hapus.php?id=5)
$id = $_GET['id'] ?? null;

// Jika ada id yang dikirim melalui URL
if ($id) {
    // Buat query untuk menghapus data mata kuliah berdasarkan ID
    $stmt = $conn->prepare("DELETE FROM mata_kuliah WHERE id = ?");
    $stmt->bind_param("i", $id); // Bind parameter ID ke dalam query
    $stmt->execute(); // Jalankan query hapus
}

// Setelah proses hapus selesai, redirect ke halaman index (daftar mata kuliah)
header("Location: index.php");
exit; // Hentikan proses PHP agar tidak lanjut membaca baris berikutnya
