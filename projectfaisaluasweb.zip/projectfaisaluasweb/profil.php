<?php
session_start(); // Mulaiin session, soalnya kita mau ambil data user yang lagi login

include 'includes/auth.php';   // Biar halaman ini gak bisa dibuka sembarang orang, harus login dulu
include 'includes/header.php'; // Tampilkan bagian atas kayak navbar, judul halaman, dsb
?>

<!-- Container dari Bootstrap, dikasih margin atas biar gak nempel -->
<div class="container mt-4">
    <!-- Card dari Bootstrap buat bungkus tampilan profil -->
    <div class="card">

        <!-- Header card-nya, warnanya biru dan tulisannya putih -->
        <div class="card-header bg-primary text-white">
            <h4 class="mb-0">Profil Pengguna</h4> <!-- Judulnya, gak pakai margin bawah -->
        </div>

        <!-- Isi dari profil -->
        <div class="card-body">
            <!-- Tampilkan username dari session -->
            <p>
                <strong>Username:</strong>
                <?= htmlspecialchars($_SESSION['username'] ?? 'Tidak diketahui') ?>
                <!-- Pakai htmlspecialchars biar aman dari script jahat (XSS) -->
            </p>

            <!-- Tampilkan nama lengkap user, kalo belum ada ya ditulis "Belum diatur" -->
            <p>
                <strong>Nama Lengkap:</strong>
                <?= htmlspecialchars($_SESSION['nama'] ?? 'Belum diatur') ?>
            </p>

            <!-- Tampilkan email user, sama juga fallback kalau belum diset -->
            <p>
                <strong>Email:</strong>
                <?= htmlspecialchars($_SESSION['email'] ?? 'Belum diatur') ?>
            </p>

            <!-- Kalau mau nambah data lain (misal role, no HP, alamat), tinggal tambah aja kayak contoh di bawah -->
            <!-- Contoh: <p><strong>Level Akses:</strong> <?= $_SESSION['role'] ?? 'User' ?></p> -->
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; // Tampilkan bagian bawah halaman (footer) ?>
