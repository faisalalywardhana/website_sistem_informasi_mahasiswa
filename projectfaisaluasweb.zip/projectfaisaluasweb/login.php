<?php
// Mulai session, penting buat nyimpen status login user
session_start();

// Panggil koneksi ke database
include 'includes/db.php';
// Panggil fungsi-fungsi tambahan (kayak redirect)
include 'includes/functions.php';

$error = ''; // Buat nampung pesan error

// Cek apakah form login dikirim
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil input dari form, terus dirapihin (trim buat hapus spasi depan/belakang)
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Pastikan username dan password gak kosong
    if ($username && $password) {
        // Query cari user dari database berdasarkan username (gak case-sensitive)
        $sql  = "SELECT * FROM users WHERE LOWER(username) = LOWER(?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username); // Masukkan username ke query
        $stmt->execute();
        $result = $stmt->get_result();

        // Kalau usernya ketemu (1 data aja)
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc(); // Ambil datanya

            // Cek password yang dimasukin sama gak dengan yang disimpan (hash)
            if (password_verify($password, $user['password'])) {
                // Simpan data user ke session biar dianggap login
                $_SESSION['user_id']  = $user['id'];
                $_SESSION['username'] = $user['username'];

                // Cek apakah checkbox "Remember Me" dicentang
                if (isset($_POST['remember'])) {
                    // Simpan username ke cookie selama 10 tahun (biar auto keisi)
                    setcookie('remember_user', $user['username'], time() + (10 * 365 * 86400), "/");
                } else {
                    // Kalau gak dicentang, hapus cookie sebelumnya (kalau ada)
                    setcookie('remember_user', '', time() - 3600, "/");
                }

                // Arahkan ke halaman utama setelah login sukses
                redirect('index.php');
            } else {
                $error = "Password salah."; // Kalau password salah
            }
        } else {
            $error = "Username tidak ditemukan."; // Kalau username gak ketemu
        }
    } else {
        $error = "Harap isi username dan password."; // Kalau input kosong
    }
}

// Ambil username dari cookie kalau pernah dicentang Remember Me
$username_prefill = $_COOKIE['remember_user'] ?? '';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <!-- Pake Bootstrap CDN biar tampilannya rapi -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light"> <!-- Background-nya abu muda -->
    <div class="container mt-5"> <!-- Kasih jarak atas -->
        <div class="col-md-4 mx-auto"> <!-- Bikin form login di tengah -->
            <div class="card shadow"> <!-- Kotaknya pakai shadow biar elegan -->
                <div class="card-header">Login</div>
                <div class="card-body">
                    <!-- Kalau ada error (kayak username/password salah), tampilkan alert -->
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>

                    <!-- Form login -->
                    <form method="POST">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" name="username" id="username"
                                class="form-control" required
                                value="<?= htmlspecialchars($username_prefill) ?>"> <!-- Auto isi dari cookie -->
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" name="password" id="password"
                                class="form-control" required>
                        </div>

                        <!-- Checkbox Remember Me -->
                        <div class="form-check mb-3">
                            <input type="checkbox" class="form-check-input" name="remember"
                                id="remember" <?= $username_prefill ? 'checked' : '' ?>>
                            <label class="form-check-label" for="remember">Remember Me</label>
                        </div>

                        <!-- Tombol submit -->
                        <button type="submit" class="btn btn-primary w-100">Login</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
