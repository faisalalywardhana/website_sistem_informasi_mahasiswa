<?php
// Mulai session untuk memastikan user login
session_start();

// Import koneksi database
include '../includes/db.php';

// Cek apakah user sudah login
include '../includes/auth.php';

// Tampilkan header (navbar, dll)
include '../includes/header.php';

// Ambil keyword dari input pencarian (jika ada)
$keyword = $_GET['search'] ?? '';

// Query SQL untuk ambil data kelas berdasarkan pencarian nama_kelas
$sql = "SELECT * FROM kelas WHERE nama_kelas LIKE ? ORDER BY id DESC";
$stmt = $conn->prepare($sql);

// Siapkan keyword pencarian dengan wildcard
$likeKeyword = '%' . $keyword . '%';
$stmt->bind_param("s", $likeKeyword);

// Eksekusi query
$stmt->execute();
$result = $stmt->get_result(); // Ambil hasil query
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Data Kelas</h4>
        <!-- Tombol buat nambah kelas baru -->
        <a href="tambah.php" class="btn btn-success">+ Tambah Kelas</a>
    </div>

    <!-- Form pencarian kelas -->
    <form method="GET" class="mb-3">
        <input type="text" name="search" class="form-control" placeholder="Cari kelas..." value="<?= htmlspecialchars($keyword) ?>">
    </form>

    <!-- Tabel daftar kelas -->
    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Nama Kelas</th>
                <th>Aksi</th> <!-- Buat tombol edit/hapus -->
            </tr>
        </thead>
        <tbody>
            <!-- Loop data kelas yang didapat dari database -->
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['nama_kelas']) ?></td>
                    <td>
                        <!-- Tombol edit dan hapus -->
                        <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; // Tampilkan bagian footer ?>
