<?php
// Mulai session supaya bisa akses data user login
session_start();

// Include koneksi database
include '../includes/db.php';

// Cek apakah user sudah login (fungsi auth)
include '../includes/auth.php';

// Tampilkan header (biasanya navbar, dll)
include '../includes/header.php';

// Variabel untuk menampung pesan error dan input default
$error = '';
$nama_kelas = '';

// Proses ketika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari input form
    $nama_kelas = $_POST['nama_kelas'] ?? '';

    // Validasi: pastikan input tidak kosong
    if (!empty($nama_kelas)) {
        // Siapkan dan jalankan query INSERT
        $stmt = $conn->prepare("INSERT INTO kelas (nama_kelas) VALUES (?)");
        $stmt->bind_param("s", $nama_kelas);
        $stmt->execute();

        // Setelah berhasil, arahkan kembali ke halaman index
        header("Location: index.php");
        exit;
    } else {
        // Tampilkan pesan error kalau input kosong
        $error = "Nama kelas tidak boleh kosong.";
    }
}
?>

<div class="container mt-4">
    <h4>Tambah Kelas</h4>

    <!-- Tampilkan pesan error jika ada -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form input data kelas -->
    <form method="POST">
        <div class="mb-3">
            <label for="nama_kelas" class="form-label">Nama Kelas</label>
            <input type="text" name="nama_kelas" id="nama_kelas" class="form-control" required>
        </div>

        <!-- Tombol simpan dan kembali -->
        <button class="btn btn-success">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php 
// Tampilkan footer halaman
include '../includes/footer.php'; 
?>
