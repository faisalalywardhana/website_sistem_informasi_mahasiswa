<?php
// Mulai sesi
session_start();

// Include file koneksi database, pengecekan login, dan tampilan header
include '../includes/db.php';
include '../includes/auth.php';
include '../includes/header.php';

// Ambil ID dari parameter URL
$id = $_GET['id'] ?? null;

// Inisialisasi variabel error dan nama_kelas
$error = '';
$nama_kelas = '';

// Ambil data lama dari database berdasarkan ID
if ($id) {
    $stmt = $conn->prepare("SELECT * FROM kelas WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $kelas = $result->fetch_assoc();

    // Kalau data tidak ditemukan, tampilkan pesan
    if (!$kelas) {
        echo "<div class='container mt-4 alert alert-danger'>Kelas tidak ditemukan. <a href='index.php'>Kembali</a></div>";
        include '../includes/footer.php';
        exit;
    }

    // Isi variabel untuk ditampilkan di form
    $nama_kelas = $kelas['nama_kelas'];
} else {
    // Kalau tidak ada ID di URL
    echo "<div class='container mt-4 alert alert-danger'>ID tidak ditemukan. <a href='index.php'>Kembali</a></div>";
    include '../includes/footer.php';
    exit;
}

// Proses update data jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_kelas = $_POST['nama_kelas'] ?? '';

    // Validasi input
    if (!empty($nama_kelas)) {
        $stmt = $conn->prepare("UPDATE kelas SET nama_kelas = ? WHERE id = ?");
        $stmt->bind_param("si", $nama_kelas, $id);
        $stmt->execute();

        // Arahkan kembali ke halaman index setelah update
        header("Location: index.php");
        exit;
    } else {
        // Tampilkan pesan error kalau input kosong
        $error = "Nama kelas tidak boleh kosong.";
    }
}
?>

<div class="container mt-4">
    <h4>Edit Kelas</h4>

    <!-- Tampilkan pesan error kalau ada -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form edit kelas -->
    <form method="POST">
        <div class="mb-3">
            <label for="nama_kelas" class="form-label">Nama Kelas</label>
            <input type="text" name="nama_kelas" id="nama_kelas" class="form-control" value="<?= htmlspecialchars($nama_kelas) ?>" required>
        </div>
        <button class="btn btn-primary">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
