<?php
// Mulai sesi dan koneksi ke database serta cek autentikasi login
session_start();
include '../includes/db.php';
include '../includes/auth.php';

// Ambil ID dari parameter URL (kalau ada)
$id = $_GET['id'] ?? null;

if ($id) {
    // Cek dulu apakah data kelas dengan ID ini ada
    $stmt = $conn->prepare("SELECT * FROM kelas WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        // Kalau ketemu, langsung hapus datanya dari database
        $stmt = $conn->prepare("DELETE FROM kelas WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}

// Setelah selesai, balik lagi ke halaman daftar kelas
header("Location: index.php");
exit;
