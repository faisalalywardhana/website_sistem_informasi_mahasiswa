<?php
// Mulai session biar bisa akses data login
session_start();

// Masukin file buat konek ke DB, cek login, dan tampilan header
include '../includes/db.php';
include '../includes/auth.php';
include '../includes/header.php';

// Ambil data dosen, matkul, dan kelas buat isi dropdown-nya
$dosen = $conn->query("SELECT id, nama FROM dosen");
$mata_kuliah = $conn->query("SELECT id, nama_mk FROM mata_kuliah");
$kelas = $conn->query("SELECT id, nama_kelas FROM kelas");

$error = ''; // Buat nampung pesan error kalau ada

// Kalau user klik tombol submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data yang dikirim dari form
    $dosen_id = $_POST['dosen_id'] ?? '';
    $mata_kuliah_id = $_POST['mata_kuliah_id'] ?? '';
    $kelas_id = $_POST['kelas_id'] ?? '';
    $hari = $_POST['hari'] ?? '';
    $jam = $_POST['jam'] ?? '';

    // Cek dulu, semua inputan harus diisi
    if ($dosen_id && $mata_kuliah_id && $kelas_id && $hari && $jam) {
        // Kalau lengkap, langsung simpan ke DB
        $sql = "INSERT INTO jadwal_kuliah (dosen_id, mata_kuliah_id, kelas_id, hari, jam) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiiss", $dosen_id, $mata_kuliah_id, $kelas_id, $hari, $jam);
        $stmt->execute();

        // Setelah berhasil disimpan, balik ke halaman utama
        header("Location: index.php");
        exit;
    } else {
        // Kalau masih ada yang kosong, tampilkan error
        $error = "Semua field harus diisi.";
    }
}
?>

<div class="container mt-4">
    <h4>Tambah Jadwal Kuliah</h4>

    <!-- Tampilkan pesan error kalau ada -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form buat input data jadwal -->
    <form method="POST">
        <!-- Pilih dosennya -->
        <div class="mb-3">
            <label for="dosen_id" class="form-label">Dosen</label>
            <select name="dosen_id" id="dosen_id" class="form-control" required>
                <option value="">-- Pilih Dosen --</option>
                <?php while ($d = $dosen->fetch_assoc()): ?>
                    <option value="<?= $d['id'] ?>"><?= htmlspecialchars($d['nama']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- Pilih mata kuliahnya -->
        <div class="mb-3">
            <label for="mata_kuliah_id" class="form-label">Mata Kuliah</label>
            <select name="mata_kuliah_id" id="mata_kuliah_id" class="form-control" required>
                <option value="">-- Pilih Mata Kuliah --</option>
                <?php while ($mk = $mata_kuliah->fetch_assoc()): ?>
                    <option value="<?= $mk['id'] ?>"><?= htmlspecialchars($mk['nama_mk']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- Pilih kelasnya -->
        <div class="mb-3">
            <label for="kelas_id" class="form-label">Kelas</label>
            <select name="kelas_id" id="kelas_id" class="form-control" required>
                <option value="">-- Pilih Kelas --</option>
                <?php while ($k = $kelas->fetch_assoc()): ?>
                    <option value="<?= $k['id'] ?>"><?= htmlspecialchars($k['nama_kelas']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- Input hari jadwal -->
        <div class="mb-3">
            <label for="hari" class="form-label">Hari</label>
            <input type="text" name="hari" id="hari" class="form-control" required>
        </div>

        <!-- Input jam kuliah -->
        <div class="mb-3">
            <label for="jam" class="form-label">Jam</label>
            <input type="text" name="jam" id="jam" class="form-control" required placeholder="Contoh: 08:00 - 10:00">
        </div>

        <!-- Tombol simpan dan balik -->
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; // Tambahin bagian footer buat nutup halaman ?>
