<?php
// Mulai session biar bisa cek login
session_start();

include '../includes/db.php';     // Koneksi DB
include '../includes/auth.php';  // Proteksi login
include '../includes/header.php';// Header tampilan

// --- Ambil ID yang mau diedit ---
$id = $_GET['id'] ?? 0;

// --- Ambil data jadwal berdasar ID ---
$stmt = $conn->prepare("SELECT * FROM jadwal_kuliah WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$jadwal = $stmt->get_result()->fetch_assoc();

// Kalau data ga ketemu, stop di sini
if (!$jadwal) {
    echo "<div class='container mt-4'><div class='alert alert-danger'>Data tidak ditemukan.</div></div>";
    include '../includes/footer.php';
    exit;
}

// --- Ambil data dropdown ---
$dosen       = $conn->query("SELECT id, nama FROM dosen");
$mata_kuliah = $conn->query("SELECT id, nama_mk FROM mata_kuliah");
$kelas       = $conn->query("SELECT id, nama_kelas FROM kelas");

$error = '';

// --- Proses form ketika disubmit ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dosen_id        = $_POST['dosen_id']        ?? '';
    $mata_kuliah_id  = $_POST['mata_kuliah_id']  ?? '';
    $kelas_id        = $_POST['kelas_id']        ?? '';
    $hari            = $_POST['hari']            ?? '';
    $jam             = $_POST['jam']             ?? '';

    // Validasi
    if ($dosen_id && $mata_kuliah_id && $kelas_id && $hari && $jam) {
        $sql  = "UPDATE jadwal_kuliah 
                SET dosen_id=?, mata_kuliah_id=?, kelas_id=?, hari=?, jam=? 
                WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiissi", $dosen_id, $mata_kuliah_id, $kelas_id, $hari, $jam, $id);
        $stmt->execute();

        header("Location: index.php"); // Balik ke list
        exit;
    } else {
        $error = "Semua field harus diisi.";
    }
}
?>

<div class="container mt-4">
    <h4>Edit Jadwal Kuliah</h4>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form edit jadwal -->
    <form method="POST">
        <!-- Dosen -->
        <div class="mb-3">
            <label class="form-label">Dosen</label>
            <select name="dosen_id" class="form-control" required>
                <option value="">-- Pilih Dosen --</option>
                <?php while ($d = $dosen->fetch_assoc()): ?>
                    <option value="<?= $d['id'] ?>" <?= $d['id'] == $jadwal['dosen_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($d['nama']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- Mata Kuliah -->
        <div class="mb-3">
            <label class="form-label">Mata Kuliah</label>
            <select name="mata_kuliah_id" class="form-control" required>
                <option value="">-- Pilih Mata Kuliah --</option>
                <?php while ($mk = $mata_kuliah->fetch_assoc()): ?>
                    <option value="<?= $mk['id'] ?>" <?= $mk['id'] == $jadwal['mata_kuliah_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($mk['nama_mk']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- Kelas -->
        <div class="mb-3">
            <label class="form-label">Kelas</label>
            <select name="kelas_id" class="form-control" required>
                <option value="">-- Pilih Kelas --</option>
                <?php while ($k = $kelas->fetch_assoc()): ?>
                    <option value="<?= $k['id'] ?>" <?= $k['id'] == $jadwal['kelas_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($k['nama_kelas']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>

        <!-- Hari -->
        <div class="mb-3">
            <label class="form-label">Hari</label>
            <input type="text" name="hari" class="form-control" required
                value="<?= htmlspecialchars($jadwal['hari'] ?? '') ?>">
        </div>

        <!-- Jam -->
        <div class="mb-3">
            <label class="form-label">Jam</label>
            <input type="text" name="jam" class="form-control" required
                value="<?= htmlspecialchars($jadwal['jam'] ?? '') ?>"
                placeholder="Contoh: 08:00 - 10:00">
        </div>

        <!-- Tombol -->
        <button type="submit" class="btn btn-success">Simpan Perubahan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
