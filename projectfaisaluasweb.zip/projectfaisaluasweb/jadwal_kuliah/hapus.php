<?php
// Mulai session dan sambungkan ke database serta auth
session_start();
include '../includes/db.php';
include '../includes/auth.php';

// Cek apakah ada ID yang dikirim lewat URL
if (isset($_GET['id'])) {
    $id = (int) $_GET['id']; // Ambil dan konversi ID ke integer (biar aman)

    // Cek dulu apakah data dengan ID ini ada di database
    $check = $conn->prepare("SELECT id FROM jadwal_kuliah WHERE id = ?");
    $check->bind_param("i", $id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        // Kalau ada, langsung eksekusi hapus data
        $stmt = $conn->prepare("DELETE FROM jadwal_kuliah WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}

// Setelah proses selesai, arahkan balik ke halaman utama jadwal
header("Location: index.php");
exit;
