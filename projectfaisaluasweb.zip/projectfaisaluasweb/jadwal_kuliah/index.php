<?php
// Mulai session biar bisa cek apakah user udah login
session_start();

// Masukin file buat koneksi ke database, middleware buat ngecek login, dan header tampilan
include '../includes/db.php';
include '../includes/auth.php';
include '../includes/header.php';

// Query buat ambil data jadwal kuliah lengkap sama dosen, matkul, dan kelas-nya
$sql = "
    SELECT 
        jk.id, 
        d.nama AS nama_dosen, 
        mk.nama_mk AS nama_mk, 
        k.nama_kelas AS nama_kelas, 
        jk.hari, 
        jk.jam_mulai, 
        jk.jam_selesai
    FROM jadwal_kuliah jk
    JOIN dosen d ON jk.dosen_id = d.id
    JOIN mata_kuliah mk ON jk.mata_kuliah_id = mk.id
    JOIN kelas k ON jk.kelas_id = k.id
    ORDER BY jk.hari, jk.jam_mulai
";

// Eksekusi query-nya
$result = $conn->query($sql);

// Kalau query-nya error, langsung berhenti dan kasih pesan
if (!$result) {
    die("Query Error: " . $conn->error);
}
?>

<div class="container mt-4">
    <h4>Data Jadwal Kuliah</h4>

    <!-- Tombol buat nambahin jadwal baru -->
    <a href="tambah.php" class="btn btn-primary mb-3">+ Tambah Jadwal</a>

    <!-- Tabel buat nampilin semua data jadwal kuliah -->
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Dosen</th>
                <th>Mata Kuliah</th>
                <th>Kelas</th>
                <th>Hari</th>
                <th>Jam</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <!-- Kalau data ada, looping dan tampilin -->
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['nama_dosen']) ?></td>
                        <td><?= htmlspecialchars($row['nama_mk']) ?></td>
                        <td><?= htmlspecialchars($row['nama_kelas']) ?></td>
                        <td><?= htmlspecialchars($row['hari']) ?></td>
                        <td><?= htmlspecialchars($row['jam_mulai']) ?> - <?= htmlspecialchars($row['jam_selesai']) ?></td>
                        <td>
                            <!-- Tombol edit dan hapus -->
                            <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <!-- Kalau belum ada data jadwal -->
                <tr>
                    <td colspan="7" class="text-center">Belum ada data jadwal kuliah.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; // Tampilkan bagian footer buat nutup halaman ?>
