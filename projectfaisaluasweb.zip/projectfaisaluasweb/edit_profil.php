<?php
session_start(); // Mulaiin session biar bisa akses data login

include 'includes/db.php';         // Koneksi ke database
include 'includes/auth.php';       // Biar halaman ini cuma bisa dibuka kalau udah login
include 'includes/header.php';     // Tampilkan bagian atas halaman (navbar, head, dsb)

$user_id = $_SESSION['user_id'] ?? null; // Ambil user_id dari session
$success = ''; // Buat nampung pesan sukses
$error = '';   // Buat nampung pesan error
$user = null;  // Variabel untuk nampung data user

// Ambil data user dari database berdasarkan id login yang lagi aktif
if ($user_id) {
    $query = "SELECT * FROM users WHERE id = $user_id";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc(); // Dapatin datanya dalam bentuk array
    } else {
        $error = "Data pengguna tidak ditemukan.";
    }
} else {
    $error = "Pengguna tidak ditemukan di sesi login.";
}

// Kalau form disubmit (POST), proses update data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name     = $_POST['name'];         // Ambil nama dari input form
    $email    = $_POST['email'];        // Ambil email dari input form
    $password = $_POST['password'];     // Ambil password baru kalau diisi

    // Query awal update nama dan email
    $update_query = "UPDATE users SET name = '$name', email = '$email'";

    // Kalau password baru diisi, hash dulu biar aman, terus update juga
    if (!empty($password)) {
        $password_hash = password_hash($password, PASSWORD_DEFAULT); // Enkripsi password
        $update_query .= ", password = '$password_hash'";
    }

    // Tambahkan kondisi WHERE biar cuma update user yang sedang login
    $update_query .= " WHERE id = $user_id";

    // Eksekusi query update-nya
    if ($conn->query($update_query)) {
        $success = "Profil berhasil diperbarui."; // Kalau berhasil

        // Ambil ulang data user dari database (data baru)
        $result = $conn->query("SELECT * FROM users WHERE id = $user_id");
        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc(); // Update data di variabel $user
        }
    } else {
        $error = "Gagal memperbarui profil."; // Kalau query gagal
    }
}
?>

<!-- Tampilan form edit profil -->
<div class="container mt-4">
    <h4>Edit Profil</h4>

    <!-- Tampilkan pesan sukses atau error kalau ada -->
    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php elseif ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Kalau data user-nya ketemu, tampilin form edit -->
    <?php if ($user): ?>
        <form method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Nama Lengkap</label>
                <input type="text" name="name" id="name" class="form-control"
                    value="<?= htmlspecialchars($user['name']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Alamat Email</label>
                <input type="email" name="email" id="email" class="form-control"
                    value="<?= htmlspecialchars($user['email'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password Baru (admin123)</label>
                <!-- Password bisa dikosongin kalau gak mau ganti -->
                <input type="password" name="password" id="password" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
            <a href="profil.php" class="btn btn-secondary">Kembali</a>
        </form>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; // Bagian bawah halaman ?>
