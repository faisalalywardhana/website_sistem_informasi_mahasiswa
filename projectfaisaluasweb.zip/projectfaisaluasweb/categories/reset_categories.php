<?php
include 'includes/db.php';

// Hapus semua data
$conn->query("DELETE FROM categories");

// Reset auto_increment ke 1
$conn->query("ALTER TABLE categories AUTO_INCREMENT = 1");

echo "Data kategori berhasil dihapus dan ID sudah di-reset.";
