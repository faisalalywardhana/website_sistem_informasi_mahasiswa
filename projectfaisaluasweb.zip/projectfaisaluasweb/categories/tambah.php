<?php
// Mulai session untuk mengelola login user
session_start();

// Panggil koneksi database dan cek apakah user sudah login
include '../includes/db.php';
include '../includes/auth.php';
include '../includes/header.php';

// Inisialisasi variabel error
$error = '';

// Cek apakah form disubmit pakai metode POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil nilai dari inputan form (nama kategori)
    $name = $_POST['name'] ?? '';

    // Validasi: pastikan nama tidak kosong
    if (!empty($name)) {
        // Siapkan query untuk insert data kategori baru ke database
        $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
        $stmt->bind_param("s", $name);
        $stmt->execute();

        // Setelah berhasil, langsung redirect ke halaman index kategori
        header("Location: index.php");
        exit;
    } else {
        // Kalau input kosong, tampilkan pesan error
        $error = "Nama kategori harus diisi.";
    }
}
?>

<!-- Tampilan halaman form tambah kategori -->
<div class="container mt-4">
    <h4>Tambah Kategori</h4>

    <!-- Tampilkan error jika ada -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form untuk menambahkan kategori baru -->
    <form method="POST">
        <div class="mb-3">
            <label for="name" class="form-label">Nama Kategori</label>
            <input type="text" name="name" id="name" class="form-control" required>
        </div>
        <button class="btn btn-success">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; ?>
