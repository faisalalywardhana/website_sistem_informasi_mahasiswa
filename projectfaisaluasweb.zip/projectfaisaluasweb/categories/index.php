<?php
// Mulai session dan include koneksi, auth, dan tampilan header
session_start();
include '../includes/db.php';
include '../includes/auth.php';
include '../includes/header.php';

// ----------------------------
// Bagian untuk fitur pencarian
// ----------------------------
$keyword = $_GET['search'] ?? ''; // Ambil keyword dari URL (jika ada)
$sql = "SELECT * FROM categories WHERE name LIKE ? ORDER BY id DESC"; // Query cari nama kategori
$stmt = $conn->prepare($sql);
$likeKeyword = '%' . $keyword . '%'; // Format keyword pakai LIKE (biar fleksibel)
$stmt->bind_param("s", $likeKeyword);
$stmt->execute();
$result = $stmt->get_result(); // Dapatkan hasilnya
?>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Data Kategori</h4>
        <!-- Tombol untuk tambah data kategori -->
        <a href="tambah.php" class="btn btn-success">+ Tambah Kategori</a>
    </div>

    <!-- Form pencarian -->
    <form method="GET" class="mb-3">
        <input type="text" name="search" class="form-control" placeholder="Cari kategori..." value="<?= htmlspecialchars($keyword) ?>">
    </form>

    <!-- Tabel data kategori -->
    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Nama Kategori</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td>
                        <!-- Tombol edit dan hapus -->
                        <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; // Footer halaman ?>
