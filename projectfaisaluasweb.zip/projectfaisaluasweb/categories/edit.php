<?php
// Mulai session dan panggil file koneksi, auth, dan header
session_start();
include '../includes/db.php';
include '../includes/auth.php';
include '../includes/header.php';

// ------------------------------
// Validasi ID dan inisialisasi variabel
// ------------------------------
$id = isset($_GET['id']) && is_numeric($_GET['id']) ? (int)$_GET['id'] : null;
$error = '';
$name = '';

// ------------------------------
// Ambil data kategori berdasarkan ID
// ------------------------------
if ($id) {
    $stmt = $conn->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $category = $result->fetch_assoc();

    // Jika data tidak ditemukan
    if (!$category) {
        echo "<div class='container mt-4 alert alert-danger'>Kategori tidak ditemukan. <a href='index.php'>Kembali</a></div>";
        include '../includes/footer.php';
        exit;
    }

    // Set nilai lama ke variabel
    $name = $category['name'];
} else {
    // Kalau ID gak valid atau kosong
    echo "<div class='container mt-4 alert alert-danger'>ID tidak ditemukan. <a href='index.php'>Kembali</a></div>";
    include '../includes/footer.php';
    exit;
}

// ------------------------------
// Proses update kategori ketika form dikirim
// ------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';

    if (!empty($name)) {
        // Update data ke database
        $stmt = $conn->prepare("UPDATE categories SET name = ? WHERE id = ?");
        $stmt->bind_param("si", $name, $id);
        $stmt->execute();

        // Redirect setelah update berhasil
        header("Location: index.php");
        exit;
    } else {
        // Jika input kosong, munculkan pesan error
        $error = "Nama kategori tidak boleh kosong.";
    }
}
?>

<!-- Tampilan form edit -->
<div class="container mt-4">
    <h4>Edit Kategori</h4>

    <?php if ($error): ?>
        <!-- Tampilkan pesan error jika ada -->
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form untuk edit kategori -->
    <form method="POST">
        <div class="mb-3">
            <label for="name" class="form-label">Nama Kategori</label>
            <input type="text" name="name" id="name" class="form-control" value="<?= htmlspecialchars($name) ?>" required>
        </div>
        <button class="btn btn-primary">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; // Footer halaman ?>
