<?php
// Mulai session
session_start();

// Panggil file koneksi dan auth (biar aman hanya user login yg bisa akses)
include '../includes/db.php';
include '../includes/auth.php';

// ------------------------------
// Validasi ID dari URL
// ------------------------------
// Cek apakah parameter 'id' dikirim dan nilainya numerik
$id = isset($_GET['id']) && is_numeric($_GET['id']) ? (int)$_GET['id'] : null;

if ($id) {
    // ------------------------------
    // Cek dulu apakah data kategori dengan ID itu ada
    // ------------------------------
    $stmt = $conn->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // ------------------------------
        // Kalau ada, lanjut hapus datanya
        // ------------------------------
        $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
}

// ------------------------------
// Setelah proses hapus, kembali ke halaman utama kategori
// ------------------------------
header("Location: index.php");
exit;
