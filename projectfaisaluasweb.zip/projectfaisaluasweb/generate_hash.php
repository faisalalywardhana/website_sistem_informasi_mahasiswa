<?php
$password = "admin123"; // sesuai dengan password yang akan kamu pakai login
echo "Password asli: " . $password . "<br>";
echo "Hash-nya: " . password_hash($password, PASSWORD_DEFAULT);