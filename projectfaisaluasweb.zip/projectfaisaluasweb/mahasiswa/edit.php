<?php
session_start(); // Mulai session biar bisa akses data login
include '../includes/db.php'; // Koneksi ke database
include '../includes/auth.php'; // Cek apakah user udah login

$id = $_GET['id'] ?? ''; // Ambil ID dari URL (buat tahu data mana yang mau diedit)
$error = '';    // Variabel buat nampung pesan error
$success = '';  // Variabel buat pesan sukses (meskipun gak dipakai di sini)

// Kalo gak ada ID, langsung balikin ke index
if (!$id) {
    header("Location: index.php");
    exit;
}

// Ambil data mahasiswa berdasarkan ID yang dikirim dari URL
$stmt = $conn->prepare("SELECT * FROM mahasiswa WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$mahasiswa = $result->fetch_assoc();

// Kalo ID gak valid atau datanya gak ada
if (!$mahasiswa) {
    die("Data tidak ditemukan.");
}

// Kalo form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil semua input dari form
    $nim     = $_POST['nim'] ?? '';
    $nama    = $_POST['nama'] ?? '';
    $jurusan = $_POST['jurusan'] ?? '';
    $sampul  = $mahasiswa['sampul']; // Default-nya foto lama

    // Validasi form, pastiin gak ada yang kosong
    if ($nim && $nama && $jurusan) {

        // Kalau user upload gambar baru
        if (isset($_FILES['sampul']) && $_FILES['sampul']['error'] === 0) {
            $namaFile = $_FILES['sampul']['name'];       // Nama file aslinya
            $tmpFile  = $_FILES['sampul']['tmp_name'];   // Tempat penyimpanan sementara

            $ext = pathinfo($namaFile, PATHINFO_EXTENSION); // Ambil ekstensi file
            $newName = uniqid() . '.' . strtolower($ext);   // Bikin nama baru biar unik

            $uploadPath = '../uploads/' . $newName; // Lokasi penyimpanan file

            // Coba upload file ke folder uploads
            if (move_uploaded_file($tmpFile, $uploadPath)) {
                // Hapus file lama (kalau ada dan namanya beda)
                if (!empty($mahasiswa['sampul']) && file_exists('../uploads/' . $mahasiswa['sampul'])) {
                    unlink('../uploads/' . $mahasiswa['sampul']); // Hapus foto lama
                }
                $sampul = $newName; // Ganti foto baru
            } else {
                $error = "Gagal mengupload gambar baru."; // Kalau gagal upload
            }
        }

        // Kalau gak ada error, lanjut update ke database
        if (!$error) {
            $stmt = $conn->prepare("UPDATE mahasiswa SET nim = ?, nama = ?, jurusan = ?, sampul = ? WHERE id = ?");
            $stmt->bind_param("ssssi", $nim, $nama, $jurusan, $sampul, $id);
            $stmt->execute();

            // Kalau berhasil, balik ke halaman utama
            header("Location: index.php");
            exit;
        }

    } else {
        $error = "Semua field wajib diisi."; // Kalau ada input yang kosong
    }
}

include '../includes/header.php'; // Tampilkan header halaman
?>

<div class="container mt-4">
    <h3>Edit Mahasiswa</h3>

    <!-- Kalau ada error, tampilkan di sini -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form edit data mahasiswa -->
    <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="nim" class="form-label">NIM</label>
            <input type="text" name="nim" id="nim" class="form-control" value="<?= htmlspecialchars($mahasiswa['nim']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" name="nama" id="nama" class="form-control" value="<?= htmlspecialchars($mahasiswa['nama']) ?>" required>
        </div>
        <div class="mb-3">
            <label for="jurusan" class="form-label">Program Studi</label>
            <input type="text" name="jurusan" id="jurusan" class="form-control" value="<?= htmlspecialchars($mahasiswa['jurusan']) ?>" required>
        </div>

        <!-- Tampilkan gambar lama kalau ada -->
        <?php if (!empty($mahasiswa['sampul'])): ?>
            <div class="mb-3">
                <label>Foto Saat Ini:</label><br>
                <img src="../uploads/<?= htmlspecialchars($mahasiswa['sampul']) ?>" alt="Sampul" width="100">
            </div>
        <?php endif; ?>

        <!-- Input untuk upload foto baru -->
        <div class="mb-3">
            <label for="sampul" class="form-label">Ganti Foto (Opsional)</label>
            <input type="file" name="sampul" id="sampul" class="form-control" accept="image/*">
        </div>

        <!-- Tombol simpan dan kembali -->
        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; // Tampilkan footer halaman ?>
