<?php
session_start();
include '../includes/db.php'; // Panggil koneksi database
include '../includes/auth.php'; // Cek apakah user udah login (biar aman)

$id = $_GET['id'] ?? '';

if ($id) {
    // Ambil data mahasiswa dulu untuk mengetahui nama file gambar (jika ada)
    $stmt = $conn->prepare("SELECT sampul FROM mahasiswa WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data = $result->fetch_assoc();

    // Hapus file gambar dari folder uploads jika ada
    if (!empty($data['sampul'])) {
        $filePath = 'uploads/' . $data['sampul'];
        if (file_exists($filePath)) {
            unlink($filePath); // Hapus file dari folder
        }
    }

    // Hapus data dari database
    $stmt = $conn->prepare("DELETE FROM mahasiswa WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

// Setelah selesai, kembali ke halaman index
header("Location: index.php");
exit;
