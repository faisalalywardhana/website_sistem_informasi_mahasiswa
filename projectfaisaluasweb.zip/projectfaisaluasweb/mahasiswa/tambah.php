<?php
include '../includes/auth.php'; // Cek apakah user udah login (biar aman)
include '../includes/db.php'; // Panggil koneksi database
include '../includes/header.php'; // Header tampilan HTML

$error = '';    // Buat nampung pesan error (kalau ada)
$success = '';  // Buat nampung pesan sukses (kalau berhasil simpan)

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil inputan dari form
    $nama    = $_POST['nama'] ?? '';
    $nim     = $_POST['nim'] ?? '';
    $jurusan = $_POST['jurusan'] ?? '';
    $sampul  = ''; // Buat nama file foto (kalau diupload)

    // Validasi: pastiin semua kolom wajib diisi
    if ($nama && $nim && $jurusan) {
        // Cek apakah user upload file gambar
        if (isset($_FILES['sampul']) && $_FILES['sampul']['error'] === 0) {
            $namaFile = $_FILES['sampul']['name'];       // Nama file aslinya
            $tmpFile  = $_FILES['sampul']['tmp_name'];   // Tempat penyimpanan sementara
            $ext = strtolower(pathinfo($namaFile, PATHINFO_EXTENSION)); // Ekstensi file (jpg/png)
            $allowed = ['jpg', 'jpeg', 'png']; // Daftar ekstensi yang diizinkan

            // Cek apakah ekstensi file valid
            if (in_array($ext, $allowed)) {
                $newName = uniqid() . '.' . $ext; // Bikin nama unik buat file biar nggak bentrok
                $uploadPath = '../uploads/' . $newName; // Path penyimpanan file

                // Coba upload file ke folder uploads
                if (move_uploaded_file($tmpFile, $uploadPath)) {
                    $sampul = $newName; // Simpan nama file ke database
                } else {
                    $error = "Gagal mengupload gambar."; // Kalau gagal upload
                }
            } else {
                $error = "Ekstensi file tidak diizinkan (hanya JPG, JPEG, PNG)."; // Kalau file bukan gambar
            }
        }

        // Kalau semua aman, masukin ke database
        if (!$error) {
            $stmt = $conn->prepare("INSERT INTO mahasiswa (nama, nim, jurusan, sampul) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nama, $nim, $jurusan, $sampul);

            // Cek apakah query insert berhasil
            if ($stmt->execute()) {
                $success = "Data berhasil ditambahkan."; // Sukses simpan ke database
            } else {
                $error = "Gagal menambahkan data ke database."; // Kalau query insert gagal
            }
        }
    } else {
        $error = "Semua kolom wajib diisi."; // Kalau ada form yang kosong
    }
}
?>

<div class="container">
    <h3>Tambah Mahasiswa</h3>

    <!-- Tampil pesan error kalau ada -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Tampil pesan sukses kalau berhasil -->
    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- Form input data mahasiswa -->
    <form method="POST" enctype="multipart/form-data"> <!-- enctype wajib dipakai kalau mau upload file -->
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" required> <!-- Input nama -->
        </div>
        <div class="mb-3">
            <label>NIM</label>
            <input type="text" name="nim" class="form-control" required> <!-- Input NIM -->
        </div>
        <div class="mb-3">
            <label>Jurusan</label>
            <input type="text" name="jurusan" class="form-control" required> <!-- Input jurusan -->
        </div>
        <div class="mb-3">
            <label>Foto Sampul (Opsional)</label>
            <input type="file" name="sampul" class="form-control" accept="image/*"> <!-- Upload foto mahasiswa -->
        </div>

        <button type="submit" class="btn btn-primary">Simpan</button> <!-- Tombol simpan -->
        <a href="index.php" class="btn btn-secondary">Kembali</a> <!-- Tombol kembali ke list -->
    </form>
</div>

<?php include '../includes/footer.php'; // Footer halaman ?>
