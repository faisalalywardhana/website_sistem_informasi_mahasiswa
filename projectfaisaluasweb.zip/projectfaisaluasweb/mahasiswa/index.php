<?php
session_start(); // Mulai session, buat ngecek apakah user udah login atau belum
include '../includes/db.php'; // Include file koneksi ke database
include '../includes/auth.php'; // Include file auth, biar halaman ini cuma bisa diakses kalo udah login
include '../includes/header.php'; // Include header tampilan HTML (biar konsisten)

$keyword = $_GET['search'] ?? ''; // Ambil data pencarian dari URL, kalo kosong diisi string kosong
$sql     = "SELECT * FROM mahasiswa"; // Query dasar buat ngambil semua data mahasiswa
$params  = []; // Buat nyiapin parameter nanti kalo user cari nama/NIM

// Cek apakah keyword pencarian diisi
if (!empty($keyword)) {
    $sql .= " WHERE nama LIKE ? OR nim LIKE ?"; // Tambahin kondisi pencarian di SQL
    $like   = "%$keyword%"; // Format keyword biar bisa cari yang mirip-mirip (pakai LIKE)
    $params = [$like, $like]; // Masukin keyword ke parameter
}

$stmt = $conn->prepare($sql); // Siapin statement ke database

// Cek kalo ada parameter (berarti ada pencarian), baru bind
if (!empty($params)) {
    $stmt->bind_param("ss", ...$params); // Bind parameter ke query (dua string: nama dan nim)
}

$stmt->execute(); // Eksekusi query
$result = $stmt->get_result(); // Ambil hasil query
?>

<div class="container mt-4">
    <h3>Data Mahasiswa</h3>

    <!-- Form pencarian -->
    <form method="GET" class="row g-3 mb-3">
        <div class="col-auto">
            <!-- Biar isian tetap muncul habis pencarian -->
            <input
                type="text"
                name="search"
                class="form-control"
                placeholder="Cari nama atau NIM"
                value="<?= htmlspecialchars($keyword) ?>" 
            >
        </div>
        <div class="col-auto">
            <button class="btn btn-primary">Cari</button> <!-- Tombol cari -->
            <a href="index.php" class="btn btn-secondary">Reset</a> <!-- Tombol reset pencarian -->
        </div>
        <div class="col-auto ms-auto">
            <a href="tambah.php" class="btn btn-success">+ Tambah Mahasiswa</a> <!-- Tombol tambah data -->
        </div>
    </form>

    <!-- Tabel buat nampilin data -->
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Foto</th> <!-- Kolom buat nampilin foto -->
                <th>NIM</th>
                <th>Nama</th>
                <th>Program Studi</th>
                <th>Aksi</th> <!-- Buat edit/hapus -->
            </tr>
        </thead>
        <tbody>
        <?php if ($result->num_rows > 0): ?> <!-- Cek apakah ada data yang ditampilin -->
            <?php $no = 1; while ($row = $result->fetch_assoc()): ?> <!-- Loop data dari database -->
                <tr>
                    <td><?= $no++ ?></td> <!-- Nomor urut -->
                    <td>
                        <?php if (!empty($row['sampul']) && file_exists("../uploads/" . $row['sampul'])): ?>
                            <!-- Cek apakah file foto tersedia di folder uploads -->
                            <img src="../uploads/<?= htmlspecialchars($row['sampul']) ?>" width="80" height="80" style="object-fit: cover; border-radius: 5px;">
                        <?php else: ?>
                            <span>-</span> <!-- Kalau gak ada foto -->
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($row['nim']) ?></td> <!-- NIM Mahasiswa -->
                    <td><?= htmlspecialchars($row['nama']) ?></td> <!-- Nama Mahasiswa -->
                    <td><?= htmlspecialchars($row['jurusan']) ?></td> <!-- Program Studi -->
                    <td>
                        <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a> <!-- Link ke halaman edit -->
                        <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin hapus?')">Hapus</a> <!-- Link hapus data -->
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <!-- Kalau gak ada data sama sekali -->
            <tr>
                <td colspan="6" class="text-center">Tidak ada data</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; // Include file footer ?>
