<?php
// Mulai sesi login dulu, biar bisa akses data user yang login
session_start();

// Cek apakah user udah login atau belum
// Kalau belum login, langsung dialihkan ke halaman login
if (!isset($_SESSION['user_id'])) {
    header("Location: users/login.php"); // lempar ke login.php
    exit;
}

// Masukkan file header (isinya navbar, link CSS, dsb)
include 'includes/header.php';
?>

<!-- Bagian judul utama di tengah halaman -->
<div class="text-center my-5">
    <div class="welcome-box">
        <!-- Ini teks sambutan, buat kesan pertama pas user login -->
        <h1 class="mb-4">Selamat Datang di Sistem Informasi Mahasiswa</h1>
    </div>
</div>

<!-- Container utama, isinya kumpulan menu dalam bentuk card -->
<div class="container">
    <div class="row">

        <!-- ================== CARD 1: Mahasiswa ================== -->
        <div class="col-md-3 mb-3">
            <div class="card border-primary">
                <div class="card-body">
                    <h5 class="card-title">Data Mahasiswa</h5>
                    <a href="mahasiswa/index.php" class="btn btn-primary btn-sm">Lihat Data</a>
                </div>
            </div>
        </div>

        <!-- ================== CARD 2: Dosen ================== -->
        <div class="col-md-3 mb-3">
            <div class="card border-success">
                <div class="card-body">
                    <h5 class="card-title">Data Dosen</h5>
                    <a href="dosen/index.php" class="btn btn-success btn-sm">Lihat Data</a>
                </div>
            </div>
        </div>

        <!-- ================== CARD 3: Mata Kuliah ================== -->
        <div class="col-md-3 mb-3">
            <div class="card border-info">
                <div class="card-body">
                    <h5 class="card-title">Data Mata Kuliah</h5>
                    <a href="mata_kuliah/index.php" class="btn btn-info btn-sm">Lihat Data</a>
                </div>
            </div>
        </div>

        <!-- ================== CARD 4: Kelas ================== -->
        <div class="col-md-3 mb-3">
            <div class="card border-warning">
                <div class="card-body">
                    <h5 class="card-title">Data Kelas</h5>
                    <!-- text-white biar teks tombol tetap kebaca -->
                    <a href="kelas/index.php" class="btn btn-warning btn-sm text-white">Lihat Data</a>
                </div>
            </div>
        </div>

        <!-- ================== CARD 5: Jadwal Kuliah ================== -->
        <div class="col-md-3 mb-3">
            <div class="card border-danger">
                <div class="card-body">
                    <h5 class="card-title">Jadwal Kuliah</h5>
                    <a href="jadwal_kuliah/index.php" class="btn btn-danger btn-sm">Lihat Data</a>
                </div>
            </div>
        </div>

        <!-- ================== CARD 6: Kategori Kelas ================== -->
        <div class="col-md-3 mb-3">
            <div class="card border-info">
                <div class="card-body">
                    <h5 class="card-title">Kategori Kelas</h5>
                    <a href="categories/index.php" class="btn btn-info btn-sm">Lihat Data</a>
                </div>
            </div>
        </div>

        <!-- Kalau mau nambah menu lain, tinggal duplikat aja salah satu card di atas -->

    </div>
</div>

<?php
// Tambahkan bagian footer, biasanya isi info hak cipta / JS tambahan
include 'includes/footer.php';
?>
