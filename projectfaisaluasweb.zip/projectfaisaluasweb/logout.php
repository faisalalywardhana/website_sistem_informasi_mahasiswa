<?php
// Mulai session dulu (wajib di awal kalau mau mainin session)
session_start();

// Bersihin semua variabel di session (kayak user_id, username, dll)
session_unset();

// Hapus session dari server (biar bener-bener logout)
session_destroy();

// Kalau sebelumnya user pakai fitur "Remember Me", kita hapus juga cookienya
if (isset($_COOKIE['remember_user'])) {
    // Bikin cookienya kadaluarsa supaya terhapus
    setcookie('remember_user', '', time() - 3600, "/");
}

// Setelah semua beres, arahkan user balik ke halaman login
header("Location: login.php");
exit; // Stop proses, biar gak lanjut ke mana-mana lagi
?>
