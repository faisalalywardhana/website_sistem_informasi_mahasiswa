<?php

// Fungsi untuk redirect ke halaman lain
function redirect($url) {
    header("Location: $url"); // arahkan ke URL tujuan
    exit; // pastikan script berhenti setelah redirect
}

// Fungsi untuk menyimpan pesan flash (sekali tampil aja, biasanya setelah form)
function set_flash($msg) {
    $_SESSION['flash'] = $msg; // simpan pesan di session
}

// Fungsi untuk mengambil dan menghapus pesan flash
function get_flash() {
    if (isset($_SESSION['flash'])) {
        $msg = $_SESSION['flash']; // ambil pesan
        unset($_SESSION['flash']); // hapus supaya nggak tampil terus
        return $msg;
    }
    return null; // kalau gak ada pesan, balikin null
}

?>
