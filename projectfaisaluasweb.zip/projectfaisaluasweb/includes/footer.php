<footer class="bg-dark text-white text-center py-3 mt-5">
    <div class="container">
        <!-- Teks footer dengan copyright tahun otomatis -->
        &copy; Faizal Aly Wardhana | 2023230041 
    </div>
</footer>

<!-- Load script Bootstrap biar komponen JS (seperti navbar collapse) bisa jalan -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
