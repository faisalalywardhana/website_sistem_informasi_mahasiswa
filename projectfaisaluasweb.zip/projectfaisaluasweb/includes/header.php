<?php
// Cek dulu, kalau session belum dimulai, maka mulai session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sistem Informasi Mahasiswa</title>
    
    <!-- Link ke Bootstrap CDN biar styling-nya pakai Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Link ke file CSS custom (buatan sendiri) -->
    <link rel="stylesheet" href="/tugas_mhs/assets/css/style.css">
</head>
<body>

<!-- Navbar utama -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4"> <!-- Navbar gelap + margin bawah -->
    <div class="container"> <!-- Biar isi navbar nggak mentok ke kiri-kanan -->
        
        <!-- Brand/logo di kiri navbar -->
        <a class="navbar-brand" href="/tugas_mhs/index.php">Sistem Mahasiswa</a>

        <!-- Tombol toggle buat HP (biar navbar bisa collapsible) -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <!-- Isi menu navbar -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto"> <!-- Bagian menu sebelah kiri -->
                <!-- Link-link ke halaman-halaman fitur -->
                <li class="nav-item">
                    <a class="nav-link" href="/tugas_mhs/index.php">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/tugas_mhs/mahasiswa/index.php">Data Mahasiswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/tugas_mhs/dosen/index.php">Data Dosen</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/tugas_mhs/mata_kuliah/index.php">Data Mata Kuliah</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/tugas_mhs/kelas/index.php">Data Kelas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/tugas_mhs/jadwal_kuliah/index.php">Jadwal Kuliah</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/tugas_mhs/categories/index.php">Kategori Kelas</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/tugas_mhs/users/index.php">Data Users</a>
                </li>
            </ul>

            <!-- Teks di pojok kanan navbar, buat nampilin nama user -->
            <span class="navbar-text text-white me-3">
                Halo, <?= $_SESSION['username'] ?? 'Pengguna' ?> <!-- Kalau username gak ada, fallback ke 'Pengguna' -->
            </span>

            <!-- Tombol logout, kasih konfirmasi sebelum logout -->
            <a href="/tugas_mhs/logout.php" class="btn btn-outline-light" onclick="return confirm('Apakah Anda yakin ingin logout?')">Logout</a>
        </div>
    </div>
</nav>
