<?php
// Konfigurasi koneksi ke database
$host = "localhost";     // host database (biasanya localhost)
$user = "root";          // username database (default: root)
$pass = "";              // password database (kosong kalau default XAMPP)
$dbname = "tugas_mhs_db"; // nama database yang dipakai

// Bikin koneksi ke MySQL
$conn = new mysqli($host, $user, $pass, $dbname);

// Cek apakah koneksi berhasil atau gagal
if ($conn->connect_error) {
    // Kalau gagal, tampilkan pesan error dan hentikan script
    die("Koneksi database gagal: " . $conn->connect_error);
}
?>
