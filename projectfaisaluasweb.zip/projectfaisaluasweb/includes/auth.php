<?php
// Cek apakah session belum dimulai, kalau belum ya mulai dulu
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kalau user belum login (gak ada user_id di session), langsung tendang ke halaman login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
