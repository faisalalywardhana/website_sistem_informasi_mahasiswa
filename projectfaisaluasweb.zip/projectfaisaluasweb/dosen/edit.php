<?php
// Mulai session & include kebutuhan dasar (DB, auth, header)
session_start();
include '../includes/db.php';
include '../includes/auth.php';
include '../includes/header.php';

// Ambil ID dosen dari URL
$id = $_GET['id'] ?? null;

// Variabel untuk form + pesan
$error = '';
$success = '';
$nama = '';
$nidn = '';
$email = '';
$jurusan = '';

// ----------------------
// Ambil data dosen lama
// ----------------------
if ($id) {
    $stmt = $conn->prepare("SELECT * FROM dosen WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $dosen = $result->fetch_assoc();

    if (!$dosen) {
        // Kalau ID nggak ketemu, kasih pesan & stop
        echo "<div class='container mt-4 alert alert-danger'>Data dosen tidak ditemukan. <a href='index.php'>Kembali</a></div>";
        include '../includes/footer.php';
        exit;
    }

    // Prefill variabel buat form
    $nama    = $dosen['nama'];
    $nidn     = $dosen['nidn'];
    $email   = $dosen['email'];
    $jurusan = $dosen['jurusan'];
} else {
    // Kalau nggak ada ID ter‑pasang di URL
    echo "<div class='container mt-4 alert alert-danger'>ID tidak ditemukan. <a href='index.php'>Kembali</a></div>";
    include '../includes/footer.php';
    exit;
}

// ----------------------
// Proses update (POST)
// ----------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil input form
    $nama    = $_POST['nama']    ?? '';
    $nidn     = $_POST['nidn']     ?? '';
    $email   = $_POST['email']   ?? '';
    $jurusan = $_POST['jurusan'] ?? '';

    // Validasi: nama & NIDN wajib diisi
    if (!empty($nama) && !empty($nidn)) {
        // Update data dosen
        $stmt = $conn->prepare("UPDATE dosen SET nama = ?, nidn = ?, email = ?, jurusan = ? WHERE id = ?");
        $stmt->bind_param("ssssi", $nama, $nidn, $email, $jurusan, $id);
        $stmt->execute();

        // Selesai, balik ke halaman list
        header("Location: index.php");
        exit;
    } else {
        $error = "Nama dan NIDN tidak boleh kosong.";
    }
}
?>

<div class="container mt-4">
    <h4>Edit Data Dosen</h4>

    <!-- Pesan error kalau ada -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form edit dosen -->
    <form method="POST">
        <div class="mb-3">
            <label for="nama" class="form-label">Nama Dosen</label>
            <input type="text" name="nama" id="nama" class="form-control" value="<?= htmlspecialchars($nama) ?>" required>
        </div>
        <div class="mb-3">
            <label for="nip" class="form-label">Nidn</label>
            <input type="text" name="nidn" id="nidn" class="form-control" value="<?= htmlspecialchars($nidn) ?>" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" id="email" class="form-control" value="<?= htmlspecialchars($email) ?>">
        </div>
        <div class="mb-3">
            <label for="jurusan" class="form-label">Jurusan</label>
            <input type="text" name="jurusan" id="jurusan" class="form-control" value="<?= htmlspecialchars($jurusan) ?>">
        </div>
        <!-- Tombol aksi -->
        <button class="btn btn-primary">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; // Footer halaman ?>
