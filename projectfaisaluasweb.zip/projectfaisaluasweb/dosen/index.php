<?php
// Mulai session
session_start();

// Include file koneksi database, auth (buat keamanan akses), dan header layout
include '../includes/db.php';
include '../includes/auth.php';
include '../includes/header.php';

// Ambil keyword dari parameter pencarian (kalau ada)
$keyword = $_GET['search'] ?? '';

// Siapin query untuk ambil data dosen sesuai pencarian, diurutkan dari yang terbaru
$sql = "SELECT * FROM dosen WHERE nama LIKE ? ORDER BY id DESC";
$stmt = $conn->prepare($sql);
$likeKeyword = '%' . $keyword . '%'; // Biar bisa cari sebagian nama
$stmt->bind_param("s", $likeKeyword);
$stmt->execute();
$result = $stmt->get_result();
?>

<div class="container mt-4">
    <!-- Judul halaman dan tombol tambah -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Data Dosen</h4>
        <a href="tambah.php" class="btn btn-success">+ Tambah Dosen</a>
    </div>

    <!-- Form pencarian dosen -->
    <form method="GET" class="mb-3">
        <input type="text" name="search" class="form-control" placeholder="Cari dosen..." value="<?= htmlspecialchars($keyword) ?>">
    </form>

    <!-- Tabel data dosen -->
    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>NIDN</th>
                <th>Email</th>
                <th>Jurusan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <!-- Tampilkan data dosen -->
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['nama']) ?></td>
                <td><?= htmlspecialchars($row['nidn']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['jurusan']) ?></td>
                <td>
                    <!-- Tombol edit dan hapus -->
                    <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; ?>
