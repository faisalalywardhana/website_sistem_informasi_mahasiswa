<?php
// Mulai session dan panggil koneksi, auth, dan tampilan header
session_start();
include '../includes/db.php';
include '../includes/auth.php';
include '../includes/header.php';

// Inisialisasi pesan error dan sukses
$error = '';
$success = '';

// Cek apakah form disubmit (pakai metode POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $nama = $_POST['nama'] ?? '';
    $nidn = $_POST['nidn'] ?? '';
    $email = $_POST['email'] ?? '';
    $jurusan = $_POST['jurusan'] ?? '';

    // Validasi: nama dan NIP wajib diisi
    if ($nama && $nip) {
        // Siapkan query INSERT untuk tambah data dosen
        $stmt = $conn->prepare("INSERT INTO dosen (nama, nidn, email, jurusan) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $nama, $nip, $email, $jurusan);
        $stmt->execute();

        // Set pesan sukses
        $success = "Data dosen berhasil ditambahkan.";
    } else {
        // Kalau validasi gagal, tampilkan pesan error
        $error = "Nama dan NIDN wajib diisi.";
    }
}
?>

<div class="container mt-4">
    <h4>Tambah Dosen</h4>

    <!-- Tampilkan alert kalau ada error atau sukses -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <!-- Form input data dosen -->
    <form method="POST">
        <div class="mb-3">
            <label for="nama" class="form-label">Nama Dosen</label>
            <input type="text" name="nama" id="nama" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="nip" class="form-label">NIP</label>
            <input type="text" name="nidn" id="nip" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" id="email" class="form-control">
        </div>
        <div class="mb-3">
            <label for="jurusan" class="form-label">Jurusan</label>
            <input type="text" name="jurusan" id="jurusan" class="form-control">
        </div>
        <!-- Tombol Simpan dan Kembali -->
        <button class="btn btn-primary">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; // Footer tampilan ?>
