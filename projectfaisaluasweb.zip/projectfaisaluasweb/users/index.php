<?php
// Konek ke database dan masukin header tampilan
include '../includes/db.php';
include '../includes/header.php';

// Siapin variabel buat nampung kata pencarian
$search = '';
if (isset($_GET['search'])) {
    $search = $_GET['search']; // Ambil keyword dari URL kalau ada pencarian
}

// Query awal: ambil semua data user dari tabel
$query = "SELECT * FROM users";

// Kalau ada keyword pencarian, tambahin kondisi pencarian
if (!empty($search)) {
    $query .= " WHERE username LIKE '%$search%' OR name LIKE '%$search%' OR role LIKE '%$search%'";
}

// Eksekusi query-nya
$result = $conn->query($query);
?>

<!-- Tampilan utama -->
<div class="container mt-4">
    <h2>Data Users</h2>

    <!-- Form pencarian user -->
    <form class="d-flex mb-3" method="get">
        <!-- Input buat cari username, nama, atau role -->
        <input class="form-control me-2" type="text" name="search" placeholder="Cari username..." value="<?= htmlspecialchars($search) ?>">
        <!-- Tombol buat submit pencarian -->
        <button class="btn btn-primary me-2" type="submit">Cari</button>
        <!-- Tombol reset buat balik ke tampilan semua data -->
        <a href="index.php" class="btn btn-secondary">Reset</a>
    </form>

    <!-- Tombol buat nambah user baru -->
    <a href="tambah.php" class="btn btn-success mb-3">+ Tambah User</a>

    <!-- Tabel buat nampilin data user -->
    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>No</th>
                <th>Username</th>
                <th>Name</th>
                <th>Role</th>
                <th>Aksi</th> <!-- Buat edit & hapus -->
            </tr>
        </thead>
        <tbody>
            <?php if ($result->num_rows > 0): ?>
                <!-- Tampilkan data user satu-satu -->
                <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= htmlspecialchars($row['username']) ?></td>
                        <td><?= htmlspecialchars($row['name']) ?></td>
                        <td><?= htmlspecialchars($row['role']) ?></td>
                        <td>
                            <!-- Tombol buat edit data user -->
                            <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                            <!-- Tombol hapus, ada konfirmasi dulu biar gak kehapus asal -->
                            <a href="hapus.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus user ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <!-- Kalau gak ada data user -->
                <tr>
                    <td colspan="5" class="text-center">Tidak ada data ditemukan.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include '../includes/footer.php'; // Tutup halaman dengan footer ?>
