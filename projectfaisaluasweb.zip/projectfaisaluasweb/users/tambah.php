<?php
session_start(); // Nyalain session, biar bisa ngecek user login

include '../includes/db.php'; // Konek ke database
include '../includes/header.php'; // Manggil header tampilan (biasanya navbar, css, dsb)

// Siapin variabel yang bakal dipakai
$error = '';       // Buat nampung pesan error kalo input nggak lengkap
$username = '';    // Buat prefill username di form
$role = '';        // Buat prefill role juga

// Kalau formnya dikirim (method POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? ''; // Ambil username dari input
    $password = $_POST['password'] ?? ''; // Ambil password
    $role     = $_POST['role'] ?? '';     // Ambil role

    // Cek semua input harus diisi
    if (!empty($username) && !empty($password) && !empty($role)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Password-nya diacak biar aman

        // Simpan ke database pake prepared statement (biar aman dari SQL Injection)
        $stmt = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $hashedPassword, $role);
        $stmt->execute();

        // Setelah sukses disimpan, langsung balik ke halaman index user
        header("Location: index.php");
        exit;
    } else {
        $error = "Semua field harus diisi!"; // Kalau ada yang kosong, kasih pesan
    }
}
?>

<div class="container mt-4">
    <h4>Tambah User</h4>

    <!-- Tampilkan error kalau ada -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form buat nambah user baru -->
    <form method="POST">
        <!-- Input Username -->
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input 
                type="text" 
                name="username" 
                id="username" 
                class="form-control" 
                value="<?= htmlspecialchars($username) ?>" 
                required
            >
        </div>

        <!-- Input Password -->
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input 
                type="password" 
                name="password" 
                id="password" 
                class="form-control" 
                required
            >
        </div>

        <!-- Pilihan Role -->
        <div class="mb-3">
            <label for="role" class="form-label">Role</label>
            <select 
                name="role" 
                id="role" 
                class="form-select" 
                required
            >
                <option value="">-- Pilih Role --</option>
                <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option>
                <option value="user" <?= $role === 'user' ? 'selected' : '' ?>>User</option>
            </select>
        </div>

        <!-- Tombol Simpan dan Kembali -->
        <button class="btn btn-primary">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; // Bagian bawah halaman ?>
