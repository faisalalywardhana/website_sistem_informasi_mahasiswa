<?php
session_start();                    // Mulai session, biar bisa akses data user login

include '../includes/db.php';       // Koneksi ke database
include '../includes/header.php';   // Masukin bagian atas halaman (navbar, CSS, dll)

// -----------------------------
// Siapin variabel
// -----------------------------
$id       = $_GET['id'] ?? null; // Ambil id user dari URL
$error    = '';                  // Buat nampung pesan error
$username = '';                  // Biar input username-nya muncul pas diedit
$role     = '';                  // Buat nampilin role lama juga

// -----------------------------
// Cek apakah ID dikirim
// -----------------------------
if (!$id) {
    // Kalau gak ada ID-nya di URL, tampilkan pesan error dan stop
    echo "<div class='container mt-4 alert alert-danger'>ID tidak ditemukan. <a href='index.php'>Kembali</a></div>";
    include '../includes/footer.php';
    exit;
}

// -----------------------------
// Ambil data user dari DB
// -----------------------------
$stmt  = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user   = $result->fetch_assoc();

// Kalau data user gak ditemukan di database
if (!$user) {
    echo "<div class='container mt-4 alert alert-danger'>User tidak ditemukan. <a href='index.php'>Kembali</a></div>";
    include '../includes/footer.php';
    exit;
}

// Simpan data lama buat ditampilin di form
$username = $user['username'];
$role     = $user['role'];

// -----------------------------
// Proses saat form disubmit
// -----------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil input dari form
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $role     = $_POST['role']     ?? '';

    // Validasi: username & role gak boleh kosong
    if (!empty($username) && !empty($role)) {

        // Kalau password diisi, update juga password-nya
        if (!empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Enkripsi password
            // Query update lengkap sama password
            $stmt = $conn->prepare("UPDATE users SET username = ?, password = ?, role = ? WHERE id = ?");
            $stmt->bind_param("sssi", $username, $hashedPassword, $role, $id);
        } else {
            // Kalau password gak diubah, update username & role aja
            $stmt = $conn->prepare("UPDATE users SET username = ?, role = ? WHERE id = ?");
            $stmt->bind_param("ssi", $username, $role, $id);
        }

        $stmt->execute(); // Eksekusi query-nya

        // Balikin ke halaman list user setelah update
        header("Location: index.php");
        exit;

    } else {
        // Kalau validasi gagal
        $error = "Username dan role harus diisi.";
    }
}
?>

<!-- ===========================
    Bagian Tampilan (Form Edit)
=========================== -->
<div class="container mt-4">
    <h4>Edit User</h4>

    <!-- Kalau ada error, tampilkan alert -->
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <!-- Form buat edit data user -->
    <form method="POST">
        <!-- Input Username -->
        <div class="mb-3">
            <label class="form-label">Username</label>
            <input 
                type="text" 
                name="username" 
                class="form-control" 
                value="<?= htmlspecialchars($username) ?>" 
                required
            >
        </div>

        <!-- Input Password baru (boleh kosong kalau gak mau ganti) -->
        <div class="mb-3">
            <label class="form-label">Password (Kosongkan jika tidak ingin diubah)</label>
            <input 
                type="password" 
                name="password" 
                class="form-control"
            >
        </div>

        <!-- Dropdown buat milih Role -->
        <div class="mb-3">
            <label class="form-label">Role</label>
            <select 
                name="role" 
                class="form-select" 
                required
            >
                <option value="">-- Pilih Role --</option>
                <option value="admin" <?= $role === 'admin' ? 'selected' : '' ?>>Admin</option>
                <option value="user"  <?= $role === 'user'  ? 'selected' : '' ?>>User</option>
            </select>
        </div>

        <!-- Tombol simpan dan tombol kembali -->
        <button class="btn btn-primary">Update</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
    </form>
</div>

<?php include '../includes/footer.php'; // Footer halaman ?>
