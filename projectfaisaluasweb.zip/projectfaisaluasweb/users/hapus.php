<?php
session_start(); // Nyalain session biar bisa akses data user yang lagi login

include '../includes/db.php'; // Konek ke database

// Cek dulu, user udah login apa belum
if (!isset($_SESSION['user_id'])) {
    // Kalau belum login, langsung lempar ke halaman login
    header("Location: ../login.php");
    exit;
}

// Ambil ID user yang mau dihapus dari URL (GET)
$id = $_GET['id'] ?? null;

// Kalau ada ID-nya, baru proses hapus
if ($id) {
    // Siapin query buat hapus user berdasarkan ID
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $id); // "i" artinya data yang dikirim itu tipe integer
    $stmt->execute(); // Eksekusi query-nya
}

// Setelah proses hapus (atau kalau ID nggak ada), langsung balik ke halaman daftar user
header("Location: index.php");
exit;
